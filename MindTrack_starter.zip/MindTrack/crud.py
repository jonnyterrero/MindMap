from sqlalchemy.orm import Session
from sqlalchemy import select
from typing import List, Optional, Tuple
from datetime import date

from models import Entry
from schemas import EntryCreate, EntryUpdate

def create_entry(db: Session, payload: EntryCreate) -> Entry:
    obj = Entry(**payload.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj

def get_entries(
    db: Session,
    start: Optional[date] = None,
    end: Optional[date] = None,
    limit: int = 200,
    offset: int = 0,
) -> List[Entry]:
    stmt = select(Entry)
    if start is not None:
        stmt = stmt.where(Entry.date >= start)
    if end is not None:
        stmt = stmt.where(Entry.date <= end)
    stmt = stmt.order_by(Entry.date.desc()).limit(limit).offset(offset)
    return list(db.scalars(stmt).all())

def get_entry(db: Session, entry_id: int) -> Optional[Entry]:
    return db.get(Entry, entry_id)

def update_entry(db: Session, entry_id: int, payload: EntryUpdate) -> Optional[Entry]:
    obj = db.get(Entry, entry_id)
    if not obj:
        return None
    data = payload.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(obj, k, v)
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj

def delete_entry(db: Session, entry_id: int) -> bool:
    obj = db.get(Entry, entry_id)
    if not obj:
        return False
    db.delete(obj)
    db.commit()
    return True
