# MindTrack – Chronic Mental Health & Migraine Tracker (Python/FastAPI)

MindTrack is a small, production-ready FastAPI service that lets users track:
- Sleep (duration, quality)
- Mood
- Anxiety / Depression / Mania (bipolar-related scales)
- ADHD focus
- Migraines (occurrence, intensity, aura, meds taken)
- Medication adherence (generic list, dosages, times)
- Therapy (went, duration)
- Outside time (minutes)
- Routines followed (list of strings)
- Productivity patterns (0-100)
- Free-form notes

It’s designed so you can **tie it into GastroGuard and SkinTrack+** through a shared database or nightly CSV/JSON exports for analytics and correlations across apps.

## Quickstart

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Run API
uvicorn main:app --reload
```

Open http://127.0.0.1:8000/docs for interactive API docs.

## Endpoints (high level)
- `POST /entries` – create a daily entry
- `GET /entries` – list entries (filter by date range)
- `GET /entries/{id}` – fetch entry
- `PUT /entries/{id}` – update entry
- `DELETE /entries/{id}` – delete entry
- `GET /analytics/summary` – rolling summary (7/30/90 days)
- `GET /analytics/correlations` – correlations between migraines and numeric features
- `GET /export.csv` – export all entries as CSV (for GastroGuard / SkinTrack+ analytics)

## Data model
One `Entry` per day (you can store multiple migraine episodes in the meds list if needed). Lists like `meds` and `routines_followed` are stored as JSON.

## Integration ideas
1. **Shared SQLite DB**: point GastroGuard & SkinTrack+ to the same SQLite file (`mindtrack.db`) to run cross-app analytics.
2. **Nightly export**: call `GET /export.csv` and load the CSV into your other apps’ pandas pipelines.
3. **Correlations endpoint**: call `/analytics/correlations` from GastroGuard/ SkinTrack+ to display “whole-person” insights (e.g., low sleep quality ↔ higher migraine intensity).

## Safety
This is **not medical advice** and does not diagnose, treat, or cure any condition. Always defer medical decisions to licensed professionals.
