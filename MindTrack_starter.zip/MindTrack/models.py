from sqlalchemy import Column, Integer, Float, String, Boolean, Date, DateTime, JSON, func, Text, Index
from database import Base

class Entry(Base):
    __tablename__ = "entries"

    id = Column(Integer, primary_key=True, index=True)

    # Core
    date = Column(Date, index=True, nullable=False)

    # Sleep
    sleep_hours = Column(Float, nullable=True)           # e.g., 0..24
    sleep_quality = Column(Integer, nullable=True)       # 1..5 Likert

    # Mood & MH scales
    mood_valence = Column(Integer, nullable=True)        # -3..+3
    anxiety_level = Column(Integer, nullable=True)       # 0..10
    depression_level = Column(Integer, nullable=True)    # 0..10
    mania_level = Column(Integer, nullable=True)         # 0..10 (for bipolar)

    # ADHD / Focus / Productivity
    adhd_focus = Column(Integer, nullable=True)          # 0..10 (self-rated)
    productivity_score = Column(Integer, nullable=True)  # 0..100

    # Therapy / Outside / Routines
    therapy_minutes = Column(Integer, nullable=True)     # minutes at therapy today
    outside_minutes = Column(Integer, nullable=True)     # minutes outside/daylight
    routines_followed = Column(JSON, nullable=True)      # list[str]

    # Migraines
    migraine = Column(Boolean, nullable=False, default=False)
    migraine_intensity = Column(Integer, nullable=True)  # 0..10 if migraine
    migraine_aura = Column(Boolean, nullable=True)
    meds = Column(JSON, nullable=True)                   # list[{'name','dose_mg','at_time'}]

    notes = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

Index("idx_entries_date", Entry.date)
