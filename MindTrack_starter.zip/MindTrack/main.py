from fastapi import FastAPI, Depends, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from datetime import date, timedelta
from io import StringIO
import pandas as pd

from database import Base, engine, get_db
from sqlalchemy.orm import Session
import models, crud, schemas

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="MindTrack API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", tags=["health"])
def root():
    return {"status": "ok", "service": "MindTrack API"}

# ---------- Entries CRUD ----------

@app.post("/entries", response_model=schemas.EntryOut, tags=["entries"])
def create_entry(payload: schemas.EntryCreate, db: Session = Depends(get_db)):
    obj = crud.create_entry(db, payload)
    return obj

@app.get("/entries", response_model=List[schemas.EntryOut], tags=["entries"])
def list_entries(
    start: Optional[date] = Query(default=None),
    end: Optional[date] = Query(default=None),
    limit: int = Query(default=200, ge=1, le=10000),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    objs = crud.get_entries(db, start=start, end=end, limit=limit, offset=offset)
    return objs

@app.get("/entries/{entry_id}", response_model=schemas.EntryOut, tags=["entries"])
def get_entry(entry_id: int, db: Session = Depends(get_db)):
    obj = crud.get_entry(db, entry_id)
    if not obj:
        raise HTTPException(status_code=404, detail="Entry not found")
    return obj

@app.put("/entries/{entry_id}", response_model=schemas.EntryOut, tags=["entries"])
def update_entry(entry_id: int, payload: schemas.EntryUpdate, db: Session = Depends(get_db)):
    obj = crud.update_entry(db, entry_id, payload)
    if not obj:
        raise HTTPException(status_code=404, detail="Entry not found")
    return obj

@app.delete("/entries/{entry_id}", tags=["entries"])
def delete_entry(entry_id: int, db: Session = Depends(get_db)):
    ok = crud.delete_entry(db, entry_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Entry not found")
    return {"deleted": True, "id": entry_id}

# ---------- Export ----------

@app.get("/export.csv", tags=["export"])
def export_csv(db: Session = Depends(get_db)):
    entries = crud.get_entries(db, limit=1000000)
    records = []
    for e in entries:
        # Flatten JSON columns for CSV
        rec = {
            "id": e.id,
            "date": e.date.isoformat(),
            "sleep_hours": e.sleep_hours,
            "sleep_quality": e.sleep_quality,
            "mood_valence": e.mood_valence,
            "anxiety_level": e.anxiety_level,
            "depression_level": e.depression_level,
            "mania_level": e.mania_level,
            "adhd_focus": e.adhd_focus,
            "productivity_score": e.productivity_score,
            "therapy_minutes": e.therapy_minutes,
            "outside_minutes": e.outside_minutes,
            "migraine": e.migraine,
            "migraine_intensity": e.migraine_intensity,
            "migraine_aura": e.migraine_aura,
            "notes": (e.notes or "").replace("\n", " ").replace("\r", " ").strip(),
            "routines_followed": "|".join(e.routines_followed or []),
            "meds": "|".join([m.get("name", "") for m in (e.meds or [])]),
        }
        records.append(rec)
    df = pd.DataFrame.from_records(records)
    buf = StringIO()
    df.to_csv(buf, index=False)
    return Response(content=buf.getvalue(), media_type="text/csv")

# ---------- Analytics ----------

NUMERIC_COLS = [
    "sleep_hours",
    "sleep_quality",
    "mood_valence",
    "anxiety_level",
    "depression_level",
    "mania_level",
    "adhd_focus",
    "productivity_score",
    "therapy_minutes",
    "outside_minutes",
]

def entries_to_df(entries) -> pd.DataFrame:
    records = []
    for e in entries:
        records.append({
            "date": e.date,
            "sleep_hours": e.sleep_hours,
            "sleep_quality": e.sleep_quality,
            "mood_valence": e.mood_valence,
            "anxiety_level": e.anxiety_level,
            "depression_level": e.depression_level,
            "mania_level": e.mania_level,
            "adhd_focus": e.adhd_focus,
            "productivity_score": e.productivity_score,
            "therapy_minutes": e.therapy_minutes,
            "outside_minutes": e.outside_minutes,
            "migraine": int(bool(e.migraine)),
            "migraine_intensity": e.migraine_intensity if e.migraine_intensity is not None else 0,
        })
    return pd.DataFrame.from_records(records)

@app.get("/analytics/summary", tags=["analytics"])
def analytics_summary(
    period: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    end = date.today()
    start = end - timedelta(days=period-1)
    entries = crud.get_entries(db, start=start, end=end, limit=1000000)
    if not entries:
        return {"period_days": period, "count": 0, "averages": {}, "migraine_days": 0}

    df = entries_to_df(entries)
    averages = {col: float(df[col].dropna().mean()) for col in NUMERIC_COLS}
    migraine_days = int(df["migraine"].sum())
    return {
        "period_days": period,
        "count": len(df),
        "averages": averages,
        "migraine_days": migraine_days,
    }

@app.get("/analytics/correlations", tags=["analytics"])
def analytics_correlations(
    min_rows: int = Query(14, ge=5, le=5000),
    db: Session = Depends(get_db)
):
    entries = crud.get_entries(db, limit=1000000)
    if not entries:
        return {"rows": 0, "with_migraine_intensity": {}, "with_migraine_binary": {}}

    df = entries_to_df(entries).dropna(subset=["migraine_intensity"])
    if len(df) < min_rows:
        return {"rows": len(df), "with_migraine_intensity": {}, "with_migraine_binary": {}}

    # Pearson correlations
    corr_intensity = {}
    for col in NUMERIC_COLS:
        try:
            corr = df[[col, "migraine_intensity"]].dropna().corr().iloc[0, 1]
            if pd.notna(corr):
                corr_intensity[col] = float(corr)
        except Exception:
            pass

    # Binary migraine: difference in means (non-parametric quick glance)
    df2 = entries_to_df(entries).dropna()
    diffs = {}
    if "migraine" in df2.columns:
        for col in NUMERIC_COLS:
            try:
                a = df2[df2["migraine"] == 1][col].dropna()
                b = df2[df2["migraine"] == 0][col].dropna()
                if len(a) > 1 and len(b) > 1:
                    diffs[col] = float(a.mean() - b.mean())
            except Exception:
                pass

    return {
        "rows": int(len(df)),
        "with_migraine_intensity": corr_intensity,
        "with_migraine_binary": diffs,
    }
