from typing import Optional, List, Literal
from datetime import date, datetime
from pydantic import BaseModel, Field

class Med(BaseModel):
    name: str
    dose_mg: Optional[float] = None
    at_time: Optional[str] = None  # 'HH:MM'

class EntryBase(BaseModel):
    date: date

    sleep_hours: Optional[float] = Field(None, ge=0, le=24)
    sleep_quality: Optional[int] = Field(None, ge=1, le=5)

    mood_valence: Optional[int] = Field(None, ge=-3, le=3)
    anxiety_level: Optional[int] = Field(None, ge=0, le=10)
    depression_level: Optional[int] = Field(None, ge=0, le=10)
    mania_level: Optional[int] = Field(None, ge=0, le=10)

    adhd_focus: Optional[int] = Field(None, ge=0, le=10)
    productivity_score: Optional[int] = Field(None, ge=0, le=100)

    therapy_minutes: Optional[int] = Field(None, ge=0, le=24*60)
    outside_minutes: Optional[int] = Field(None, ge=0, le=24*60)
    routines_followed: Optional[List[str]] = None

    migraine: bool = False
    migraine_intensity: Optional[int] = Field(None, ge=0, le=10)
    migraine_aura: Optional[bool] = None
    meds: Optional[List[Med]] = None

    notes: Optional[str] = None

class EntryCreate(EntryBase):
    pass

class EntryUpdate(EntryBase):
    pass

class EntryOut(EntryBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
